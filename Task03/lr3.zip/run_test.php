<?php

require_once 'Book.php';
require_once 'BooksList.php';
require_once 'Test.php';

runTest();
